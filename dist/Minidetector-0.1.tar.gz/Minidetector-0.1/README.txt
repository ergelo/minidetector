Minidetector

Purpose
-------
This application is a simple middleware and associated decorator that
will add a ".mobile" attribute to your request objects, which, if
True, means the requester is coming to you from a mobile phone
(cellphone), PDA, or other device that should be considered small
screened, or have an underpowered browser, such as games consoles.


History
-------
This is a fork of http://code.google.com/p/minidetector/

The original project hasn't had an update since 2008, and is poorly
packaged.

This fork packaged the module and uploaded it to pypi.
